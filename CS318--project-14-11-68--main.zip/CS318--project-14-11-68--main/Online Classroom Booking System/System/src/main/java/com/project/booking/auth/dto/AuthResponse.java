package com.project.booking.auth.dto;

public record AuthResponse(
        String token
) {
}
