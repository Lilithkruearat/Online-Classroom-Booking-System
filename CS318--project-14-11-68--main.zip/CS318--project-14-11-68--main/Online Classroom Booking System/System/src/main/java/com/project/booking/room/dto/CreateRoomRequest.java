package com.project.booking.room.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;

public record CreateRoomRequest(
        @NotBlank String roomCode,
        @NotBlank String name,
        @Min(1) int capacity,
        String equipment
) {
}
