package com.project.booking.dashboard.service;

import com.project.booking.auth.repository.UserRepository;
import com.project.booking.booking.repository.BookingRepository;
import com.project.booking.common.BookingStatus;
import com.project.booking.dashboard.dto.DashboardSummary;
import com.project.booking.room.repository.RoomRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DashboardService {

    private final UserRepository userRepository;
    private final RoomRepository roomRepository;
    private final BookingRepository bookingRepository;

    public DashboardSummary getSummary() {
        long totalUsers = userRepository.count();
        long totalRooms = roomRepository.count();
        long totalBookings = bookingRepository.count();
        long pendingBookings = bookingRepository.findByStatus(BookingStatus.PENDING).size();

        Map<String, Long> bookingsByStatus = Arrays.stream(BookingStatus.values())
                .collect(Collectors.toMap(
                        Enum::name,
                        status -> (long) bookingRepository.findByStatus(status).size()
                ));

        return new DashboardSummary(
                totalUsers,
                totalRooms,
                totalBookings,
                pendingBookings,
                bookingsByStatus
        );
    }
}
