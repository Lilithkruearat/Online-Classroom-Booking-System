package com.project.booking.dashboard.dto;

import java.util.Map;

public record DashboardSummary(
        long totalUsers,
        long totalRooms,
        long totalBookings,
        long pendingBookings,
        Map<String, Long> bookingsByStatus
) {
}
