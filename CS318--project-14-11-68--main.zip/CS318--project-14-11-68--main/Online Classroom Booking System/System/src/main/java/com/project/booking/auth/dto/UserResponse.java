package com.project.booking.auth.dto;

import com.project.booking.common.UserRole;

public record UserResponse(
        Long id,
        String username,
        String email,
        UserRole role
) {
}
