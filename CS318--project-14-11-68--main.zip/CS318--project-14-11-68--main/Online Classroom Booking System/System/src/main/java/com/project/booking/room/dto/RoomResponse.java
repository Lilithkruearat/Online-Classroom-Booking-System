package com.project.booking.room.dto;

public record RoomResponse(
        Long id,
        String roomCode,
        String name,
        int capacity,
        String equipment
) {
}
