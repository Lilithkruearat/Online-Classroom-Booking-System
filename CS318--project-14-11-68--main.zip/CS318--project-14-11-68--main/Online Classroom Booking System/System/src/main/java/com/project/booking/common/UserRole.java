package com.project.booking.common;

public enum UserRole {
    ROLE_USER,
    ROLE_ADMIN
}
