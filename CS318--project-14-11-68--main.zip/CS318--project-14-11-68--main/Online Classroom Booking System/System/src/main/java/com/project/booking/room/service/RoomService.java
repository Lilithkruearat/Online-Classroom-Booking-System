package com.project.booking.room.service;

import com.project.booking.common.exception.ResourceNotFoundException;
import com.project.booking.room.dto.CreateRoomRequest;
import com.project.booking.room.dto.RoomResponse;
import com.project.booking.room.model.Room;
import com.project.booking.room.repository.RoomRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class RoomService {

    private final RoomRepository roomRepository;

    public RoomResponse createRoom(CreateRoomRequest request) {
        Room room = Room.builder()
                .roomCode(request.roomCode())
                .name(request.name())
                .capacity(request.capacity())
                .equipment(request.equipment())
                .build();
        room = roomRepository.save(room);
        return toRoomResponse(room);
    }

    public List<RoomResponse> getAllRooms() {
        return roomRepository.findAll().stream()
                .map(this::toRoomResponse)
                .collect(Collectors.toList());
    }

    public RoomResponse getRoomById(Long roomId) {
        Room room = roomRepository.findById(roomId)
                .orElseThrow(() -> new ResourceNotFoundException("Room not found with id: " + roomId));
        return toRoomResponse(room);
    }

    private RoomResponse toRoomResponse(Room room) {
        return new RoomResponse(
                room.getId(),
                room.getRoomCode(),
                room.getName(),
                room.getCapacity(),
                room.getEquipment()
        );
    }
}
