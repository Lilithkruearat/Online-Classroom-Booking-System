package com.project.booking.booking.dto;

import com.project.booking.common.BookingStatus;

import java.time.LocalDateTime;

public record BookingResponse(
        Long id,
        String roomName,
        LocalDateTime startTime,
        LocalDateTime endTime,
        BookingStatus status,
        String username,
        String purpose
) {
}
