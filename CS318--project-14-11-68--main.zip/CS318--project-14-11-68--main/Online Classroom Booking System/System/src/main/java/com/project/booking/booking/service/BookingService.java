package com.project.booking.booking.service;

import com.project.booking.auth.model.User;
import com.project.booking.booking.dto.BookingResponse;
import com.project.booking.booking.dto.CreateBookingRequest;
import com.project.booking.booking.model.Booking;
import com.project.booking.booking.repository.BookingRepository;
import com.project.booking.common.BookingStatus;
import com.project.booking.common.exception.BookingConflictException;
import com.project.booking.common.exception.ResourceNotFoundException;
import com.project.booking.room.model.Room;
import com.project.booking.room.repository.RoomRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BookingService {

    private final BookingRepository bookingRepository;
    private final RoomRepository roomRepository;

    public BookingResponse createBooking(CreateBookingRequest request) {
        User currentUser = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Room room = roomRepository.findById(request.roomId())
                .orElseThrow(() -> new ResourceNotFoundException("Room not found with id: " + request.roomId()));

        // Conflict detection
        List<Booking> conflictingBookings = bookingRepository.findConflictingBookings(
                request.roomId(), request.startTime(), request.endTime());
        if (!conflictingBookings.isEmpty()) {
            throw new BookingConflictException("The room is already booked for the selected time.");
        }

        Booking booking = Booking.builder()
                .user(currentUser)
                .room(room)
                .startTime(request.startTime())
                .endTime(request.endTime())
                .purpose(request.purpose())
                .status(BookingStatus.PENDING)
                .build();

        booking = bookingRepository.save(booking);
        return toBookingResponse(booking);
    }

    public List<BookingResponse> getMyHistory() {
        User currentUser = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return bookingRepository.findByUserId(currentUser.getId()).stream()
                .map(this::toBookingResponse)
                .collect(Collectors.toList());
    }

    public BookingResponse cancelBooking(Long bookingId) {
        User currentUser = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found with id: " + bookingId));

        if (!booking.getUser().getId().equals(currentUser.getId())) {
            // Or throw an AccessDeniedException
            throw new ResourceNotFoundException("Booking not found with id: " + bookingId);
        }

        booking.setStatus(BookingStatus.CANCELLED);
        booking = bookingRepository.save(booking);
        return toBookingResponse(booking);
    }

    public List<BookingResponse> getAllBookings(BookingStatus status) {
        List<Booking> bookings = (status == null)
                ? bookingRepository.findAll()
                : bookingRepository.findByStatus(status);
        return bookings.stream()
                .map(this::toBookingResponse)
                .collect(Collectors.toList());
    }

    public BookingResponse approveBooking(Long bookingId) {
        return updateBookingStatus(bookingId, BookingStatus.APPROVED);
    }

    public BookingResponse rejectBooking(Long bookingId) {
        return updateBookingStatus(bookingId, BookingStatus.REJECTED);
    }

    private BookingResponse updateBookingStatus(Long bookingId, BookingStatus status) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found with id: " + bookingId));
        booking.setStatus(status);
        booking = bookingRepository.save(booking);
        return toBookingResponse(booking);
    }

    private BookingResponse toBookingResponse(Booking booking) {
        return new BookingResponse(
                booking.getId(),
                booking.getRoom().getName(),
                booking.getStartTime(),
                booking.getEndTime(),
                booking.getStatus(),
                booking.getUser().getUsername(),
                booking.getPurpose()
        );
    }
}
