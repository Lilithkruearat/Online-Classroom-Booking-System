package com.project.booking.booking.repository;

import com.project.booking.booking.model.Booking;
import com.project.booking.common.BookingStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {

    List<Booking> findByUserId(Long userId);

    List<Booking> findByStatus(BookingStatus status);

    @Query("SELECT b FROM Booking b WHERE b.room.id = :roomId AND b.status = 'APPROVED' AND " +
           "(b.startTime < :endTime AND b.endTime > :startTime)")
    List<Booking> findConflictingBookings(Long roomId, LocalDateTime startTime, LocalDateTime endTime);
}
