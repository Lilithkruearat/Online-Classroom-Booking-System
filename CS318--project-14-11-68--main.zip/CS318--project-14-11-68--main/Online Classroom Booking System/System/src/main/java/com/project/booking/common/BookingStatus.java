package com.project.booking.common;

public enum BookingStatus {
    PENDING,
    APPROVED,
    REJECTED,
    CANCELLED
}
